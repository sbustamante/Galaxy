#include <allvars.h>


/*****************************************************************
 NOMBRE:     dynamic_function
 FUNCION:    integra un paso del sistema de N particulas
 ARGUMENTOS: arreglo 'cluster' con estado de particulas, paso de
	     de integracion,y entero con especificacion de metodo
	     de integracion a utilizar.
	     0 --- Runge Kutta 4
	     1 --- Euler primer orden
 RETORNA:    0
 LOG:        27/01/2011    Creacion
*****************************************************************/
int dynamic_function( struct cluster galaxy[1],
		      double t,
		      struct intg_step f[MAXNPARTICLES] )
{
    int i, j, k;
    double force_all;
    double eps;

    for( i=0; i<galaxy[0].N; i++ ){
	//Positions derivatives
	f[i].r[X] = galaxy[0].prts[i].v[X];
	f[i].r[Y] = galaxy[0].prts[i].v[Y];
	f[i].r[Z] = galaxy[0].prts[i].v[Z];
	
	//Velocities derivatives
	f[i].v[X] = 1.0;
	f[i].v[Y] = 1.0;
	f[i].v[Z] = 1.0;
	
    
    }
	
    return 0;
}


//================================================================
//			HOMOGENEUS DISK COMPONENTS
//================================================================
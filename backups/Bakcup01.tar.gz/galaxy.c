#include <allvars.h>


int main( int argc, char *argv[] )
{
    int i=0,j=0,n;
    double t=0;
    double prmt[NMAX2];
    char str[NMAX2];
    
    char filename[NMAX2];
    FILE *script;

    //Galaxy definition
    struct cluster galaxy[1];
  
    
    printf( "\n\n***************** GALAXY SIMULATION *****************\n" );
  
    //Read parameters
    if( read_parameters( prmt, "parameters.conf")==1 ) return 0;
    galaxy[0].N1 = (int)prmt[N_1];
    galaxy[0].N2 = (int)prmt[N_2];
    galaxy[0].N = galaxy[0].N1+galaxy[0].N2;
    galaxy[0].distros[HOM_DIS] = (int)prmt[6];
    galaxy[0].distros[ARM_DIS] = (int)prmt[7];
    galaxy[0].distros[BULGE  ] = (int)prmt[8];
    galaxy[0].distros[HALO_ST] = (int)prmt[9];
    galaxy[0].distros[HALO_DK] = (int)prmt[10];
    
    //Setting initial conditions
    initial_conditions( galaxy, prmt, "datos.in" );
    
    galaxy[0].prts[0].r[X] = 0;
    while( t<prmt[T_MAX] )
    {
	//Current time
	galaxy[0].t_snap = t;

	//Paso de integracion
	//integration_step( galaxy, t, prmt[T_STEP], prmt[TYP_INT] );
	
	//Impresion de datos
 	sprintf( filename, "./datas/Galaxy-%05d", j );
 	data_out( galaxy, filename );
	
	//Video y datos --------------------------
	if( argv[1]==NULL || atoi(argv[1])==1 ){
	    //Inicializacion de Script gnuplot
	    script = fopen( "script.gpl", "w" );
	    sprintf( str, "set terminal png\nset output '_tmp-%05d.png'\nset nokey\n", j );
	    fprintf( script, "%s", str );
	    sprintf( str, "set title 't = %lf'\n", t );
	    fprintf( script, "%s", str );
	    sprintf( str, "set xrange [%lf:%lf] \nset yrange [%lf:%lf]\n", -200.,350.,-200.,350. );
	    fprintf( script, "%s", str );
	    sprintf( str, "plot './datos/Galaxy-%05d' u 2:3 w p 14",j );
	    fprintf( script, "%s", str );
	    fclose(script);
	    system("gnuplot script.gpl");}
	
	//Paso del sistema
	printf( " t = %lf\n", t );
	t += prmt[T_STEP];
	j++;
    }
    
    //Eliminacion de archivos temporales -----------------
    if( argv[1]==NULL || atoi(argv[1])==1 ){
	system("ffmpeg -f image2 -i _tmp-%05d.png  video.mpg");
// 	system("convert -delay .1 -loop 0 *.png animacion.gif");
	system("rm -rf *.png");
	system("rm -rf script.gpl");}
    
    return 0;
}
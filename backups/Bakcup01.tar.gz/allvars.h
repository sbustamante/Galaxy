/********************************************************************
			       MACROS
********************************************************************/
//Macros generales
#define MAXNPARTICLES 	100000
#define NMAX1 		10
#define NMAX2 		100
#define NMAX3 		1000

//Constantes fisicas
#define GC		1

//Macros de parametros
#define N_1		0
#define N_2		1
#define T_STEP		2
#define T_MAX		3

#define TYP_INT		4

#define HOM_DIS		5
#define ARM_DIS		6
#define BAR_DIS		7
#define BULGE		8
#define HALO_ST		9
#define HALO_DK		10

#define COOR_1		11
#define COOR_2		12
#define COOR_3		13

#define VEL_1		14
#define VEL_2		15
#define VEL_3		16

#define MASS		17

//Macros de variables
#define X		0
#define Y		1
#define Z		2


/********************************************************************
			     ESTRUCTURAS
********************************************************************/

struct particle{
    double m;
    double r[3], v[3];
    double Ek, Ep;
    
    int label;
    int type;};

struct cluster{
    int N1;
    int N2;
    int N;
    
    double t_snap;
    double Ek, Ep;
    
    int distros[6];
    
    struct particle prts[MAXNPARTICLES];};
    
struct intg_step{
    double r[3], v[3];};
    
   
/********************************************************************
			      HEADERS
********************************************************************/
#include <stdio.h>
#include <math.h>
#include <proto.h>
#include <stdlib.h>
#include <time.h>
#include <allvars.h>


/********************************************************************
 NOMBRE:     initial_conditions
 FUNCION:    genera condiciones iniciales para distribucion en un 
	     archivo de salida.
 ARGUMENTOS: estructura 'cluster' para inicializar las particulas
	     en la distribucion, archivo de parametros.Nombre de 
	     archivo de salida
 RETORNA:    0							    
 LOG:        21/01/2011    Creacion                                
********************************************************************/
int initial_conditions( struct cluster galaxy[1], 
			double prmt[],
			char filename[] )
{  
    int i;
    char distribution[10];
    FILE *file;
    
    //Cubo Uniforme
    uniform_cube( galaxy, prmt );
    sprintf( distribution, "uniform_cube" );

    //Impresion en archivo
    file = fopen( filename, "w" );
    fprintf( file, "#Label\tX\t\tY\t\tZ\t\tVx\t\tVy\t\tVz\t\tMass\t\ttype\n" );
    for( i=0; i<galaxy[0].N; i++ )
	fprintf( file,"%d\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%d\n", 
		 galaxy[0].prts[i].label, 
		 galaxy[0].prts[i].r[0], galaxy[0].prts[i].r[1], galaxy[0].prts[i].r[2],
		 galaxy[0].prts[i].v[0], galaxy[0].prts[i].v[1], galaxy[0].prts[i].v[2], 
		 galaxy[0].prts[i].m, galaxy[0].prts[i].type);
	  
    fclose(file);
    
    printf( "  * Condiciones iniciales generadas!\n\tDistribución: %s\n\tArchivo de salida: '%s'\n", 
	    distribution, filename );
  
    return 0;
}


/********************************************************************
 NOMBRE:     uniform_cube                                           
 FUNCION:    genera una distribucion uniforme sobre un cubo de     
             lados dados                                           
 ARGUMENTOS: estructura 'cluster' para retorno de posicion y      
	     velocidad de cada particula y arreglo con parametros 
 COORDENADAS:							    
	     *Coord 1 -- Lado x
	     *Coord 2 -- Lado y
	     *Coord 3 -- Lado z
	     *Veloc 1 -- Magnitud maxima velocidad
	     *Veloc 2 -- NULL
	     *Veloc 3 -- NULL                 			    
 RETORNA:    0							    
 LOG:        15/09/2009    Creacion           
	     26/01/2011	   Implementacion estructura cluster
********************************************************************/
int uniform_cube( struct cluster galaxy[1], 
		  double prmt[NMAX2] )
{
    int i,j;

    srand48(time(NULL));
    //Asignacion de posiciones y velocidades
    for( i=0; i<galaxy[0].N; i++ ){
		
	//Mass
	galaxy[0].prts[i].m = prmt[MASS];
	
        //Position
	galaxy[0].prts[i].r[X] = prmt[COOR_1]*(1-2*drand48());
	galaxy[0].prts[i].r[Y] = prmt[COOR_2]*(1-2*drand48());
	galaxy[0].prts[i].r[Z] = prmt[COOR_3]*(1-2*drand48());

	//Velocity
	galaxy[0].prts[i].v[X] = (1-2*drand48())*prmt[VEL_1];
	galaxy[0].prts[i].v[Y] = (1-2*drand48())*prmt[VEL_2];
	galaxy[0].prts[i].v[Z] = (1-2*drand48())*prmt[VEL_3];
	
	//Label
	galaxy[0].prts[i].label = i;
	
	//Type
	if( i<galaxy[0].N1 )
	    //Disk star
	    galaxy[0].prts[i].type = 0;
	else
	    //Halo star
	    galaxy[0].prts[i].type = 1;}
	    
    return 0;
}